class PassengerView:
    @staticmethod
    def render_passenger(passenger):
        return jsonify({
            "Passenger_ID": passenger.Passenger_ID,
            "First_name": passenger.First_name,
            "Last_name": passenger.Last_name,
            "age": passenger.age,
            "disabilities": passenger.disabilities,
            "Email": passenger.Email,
            "Passport_number": passenger.Passport_number,
            "created_at": passenger.created_at.isoformat()
        })

    @staticmethod
    def render_passengers(passengers):
        return [PassengerView.render_passenger(passenger) for passenger in passengers]


    @staticmethod
    def render_flight(flight):
        return jsonify({
            "Flight_name": flight.Flight_name,
            "Year_of_Services": flight.Year_of_Services,
            "Flight_type": flight.Flight_type,
            "Arrival_time": flight.Arival_time.isoformat(),
            "Departure_time": flight.Departure_time.isoformat()
        })

    @staticmethod
    def render_flights(flights):
        return [PassengerView.render_flight(flight) for flight in flights]

    @staticmethod
    def render_booking(booking):
        return jsonify({
            "Passenger_ID": booking.Passenger_ID,
            "Flight_ID": booking.Flight_ID,
            "Seat_number": booking.Seat_number,
            "Class": booking.Class,
            "Age": booking.Age,
            "Gender": booking.Gender,
            "Price": booking.Price,
            "Origin_AP_CODE": booking.Origin_AP_CODE,
            "Destination_AP_CODE": booking.Destination_AP_CODE,
            "Boarding_time": booking.Boarding_time,
            "Check_in_time": booking.Check_in_time,
            "created_at": booking.created_at.isoformat()
        })

    @staticmethod
    def render_bookings(passengers):
        return [PassengerView.render_booking(booking) for booking in bookings]

    @staticmethod
    def render_review(review):
        return jsonify({
            "Passenger_ID": review.Passenger_ID,
            "Content": review.Content,
            "Rating": review.Rating,
            "Date": review.Date.isoformat()
        })

    @staticmethod
    def render_reviews(reviews):
        return [PassengerView.render_review(review) for review in reviews]

    @staticmethod
    def render_notification(notification):
        return {
            "id": notification.Notification_ID,
            "message": notification.message,
            "type": notification.notification_type,
            "status": notification.status,
            "created_at": notification.created_at
        }

    @staticmethod
    def render_notifications(notifications):
        return [PassengerView.render_notification(notification) for notification in notifications]

    @staticmethod
    def render_error(message):
        return {"error": message}

    @staticmethod
    def render_success(message, Passenger_ID=None, Booking_ID=None, Review_ID=None):
        response = {"message": message}
        if Passenger_ID:
            response["Passenger_ID"] = Passenger_ID
        return response

