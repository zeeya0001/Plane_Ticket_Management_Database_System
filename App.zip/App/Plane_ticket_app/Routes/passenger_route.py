from Plane_ticket_app.Routes.booking_routes import planeticket_bp
from Plane_ticket_app.Controllers.passenger_controller import PassengerController

@planeticket_bp.route('/get_passenger/<int:P_id>',methods=['GET'])
def get_passenger(P_id):
    return PassengerController.get_passenger(P_id)

@planeticket_bp.route('/create_passenger',methods=['POST'])
def passenger():
    return PassengerController.create_passenger()
    
@planeticket_bp.route('/login_passenger',methods=['POST'])
def login_passenger():
    return FlightController.login_passenger()