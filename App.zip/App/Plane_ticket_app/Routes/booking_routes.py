from flask import Blueprint,redirect,url_for,render_template
from Plane_ticket_app.Controllers.passenger_controller import PassengerController
from Plane_ticket_app.Controllers.booking_controller import BookingController
from Plane_ticket_app.Controllers.review_controller import ReviewController
from Plane_ticket_app.Controllers.flight_controller import FlightController

planeticket_bp = Blueprint('planeticket_bp', __name__)

@planeticket_bp.route('/',methods=['GET'])
def start():
    return render_template('Book_ticket.html')

@planeticket_bp.route('/ticket_book',methods=['POST'])
def booking():
    return BookingController.book_ticket()

@planeticket_bp.route('/get_booking/<Booking_id>',methods=['POST'])
def get_booking(Booking_id):
    return BookingController.get_booking(Booking_id)
    
@planeticket_bp.route('/process_payment',methods=['POST'])
def payment():
    return BookingController.process_payment()

@planeticket_bp.route('/get_payment_status/<Booking_id>',methods=['GET'])
def status(Booking_id):
    return BookingController.get_payment_status(Booking_id)

@planeticket_bp.route('/cancel_booking',methods=['POST'])
def cancel():
    return BookingController.cancel_booking()