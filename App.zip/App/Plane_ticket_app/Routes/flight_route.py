from Plane_ticket_app.Routes.booking_routes import planeticket_bp
from Plane_ticket_app.Controllers.flight_controller import FlightController


@planeticket_bp.route('/get_flight',methods=['POST'])
def flight():
    return FlightController.get_flight()

@planeticket_bp.route('/create_flight',methods=['POST'])
def flight():
    return FlightController.create_flight()
