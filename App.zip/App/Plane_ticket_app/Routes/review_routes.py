from Plane_ticket_app.Controllers.booking_controller import planeticket_bp
from Plane_ticket_app.Controllers.review_controller import ReviewController


@planeticket_bp.route('/get_review/<r_id>',methods=['POST'])
def get_review(r_id):
    return ReviewController.get_review(r_id)

@planeticket_bp.route('/create_review',methods=['POST'])
def create_review():
    return ReviewController.create_review()

@planeticket_bp.route('/delete_review/<r_id>',methods=['POST'])
def delete_review(r_id):
    return ReviewController.delete_review(r_id)

@planeticket_bp.route('/get_notifications/<P_id>',methods=['GET'])
def get_notifications(P_id):
    return ReviewController.get_notifications(P_id)

@planeticket_bp.route('/mark_as_read/N_id',methods=['POST'])
def mark_as_read(N_id):
    return ReviewController.mark_as_read(N_id)