from shared.models.flight_model import Flight
from shared.utils.db_utils import db

class FlightService:
    @staticmethod
    def create_flight(Flight_name, Departure_Time, Arrival_Time, Year_of_Services, Flight_type):
        new_flight = Flight(Flight_name=Flight_name, Departure_Time=Departure_Time, Arrival_Time=Arrival_Time, Year_of_Services=Year_of_Services, Flight_type=Flight_type)
        db.session.add(new_flight)
        db.session.commit()
        return new_flight

    @staticmethod
    def get_flight_by_id(Flight_name):
        return Flight.query.get(Flight_name)

    @staticmethod
    def get_all_flights():
        return Flight.query.all()
