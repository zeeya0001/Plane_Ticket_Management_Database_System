from shared.models.passenger_model import Passenger
from shared.utils.db_utils import db
from werkzeug.security import generate_password_hash, check_password_hash

class PassengerService:
    @staticmethod
    def create_passenger(Passenger_ID, email, password, First_name, Last_name, Passport_number):
        hashed_password = generate_password_hash(password)
        new_passenger = Passenger(Passenger_ID=Passenger_ID, email=email, password_hash=hashed_password, first_name=First_name, last_name=Last_name, passport_number=Passport_number)
        db.session.add(new_passenger)
        db.session.commit()

        return new_passenger

    @staticmethod
    def get_passenger_by_Passenger_ID(Passenger_ID):
        return passenger.query.filter_by(Passenger_ID=Passenger_ID).first()

    @staticmethod
    def verify_passenger(Passenger_ID, password):
        passenger = passenger.query.filter_by(Passenger_ID=Passenger_ID).first()
        if passenger and check_password_hash(passenger.password_hash, password):
            return passenger
        return None

    @staticmethod
    def delete_passenger(Passenger_ID):
        passenger = Passenger.query.get(Passenger_ID)
        if passenger:
            db.session.delete(passenger)
            db.session.commit()
            return True
        return False
    