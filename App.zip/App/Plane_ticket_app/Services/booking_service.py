from datetime import datetime
from shared.models.booking_model import Booking
from shared.models.passenger_model import Passenger
from shared.models.flight_model import Flight
from shared.models.payment_model import Payment
from shared.models.cancellation_model import Cancellation
from shared.models.seatMatrix_model import SeatMatrix
from shared.utils.db_utils import db

class BookingService:
    def book_ticket(Flight_ID, Passenger_ID, Seat_number, Class, Price):
        
        flight = Flight.query.get(Flight_ID)
        passenger = Passenger.query.get(Passenger_ID)
        seat = SeatMatrix.query.filter_by(flight_id=Flight_ID, total_seats_available=1, seat_class=Class).first()

        if not flight or not passenger:
            return {"message": "Flight or Passenger not found", "status": 404}

        if not seat or seat.passenger_id:
            return {"message": "Seat not available", "status": 400}

        if flight.total_seats_available <= 0:
            return {"message": "No seats available", "status": 400}

        # Update seat matrix
        seat.passenger_id = passenger.Passenger_ID
        flight.total_seats_available -= 1

        # Create ticket
        ticket = Booking(
            Flight_ID=flight.Flight_ID,
            Passenger_ID=passenger.Passenger_ID,
            Seat_number=Seat_number,
            Booking_date=datetime.utcnow(),
            Status="Booked"
        )
        db.session.add(ticket)
        db.session.commit()
        return ticket

    @staticmethod
    def get_booking_by_id(Booking_ID):
        return Booking.query.filter_by(Booking_ID=Booking_ID).first()

    @staticmethod
    def get_all_bookings():
        return Booking.query.all()

    @staticmethod
    def cancel_booking(Booking_ID, Request_time, Reason):
        booking = Booking.query.get(Booking_ID)
        if booking:
            cancellation = Cancellation(
                Booking_ID=Booking_ID,
                Request_time=Request_time,
                Reason=Reason
            )
            db.session.add(cancellation)
            booking.Status = "Cancelled"
            db.session.commit()
            return True
        return False

    @staticmethod
    def process_payment(Booking_ID, Amount, Payment_Method):
        new_payment = Payment(
            Booking_ID=Booking_ID, 
            Amount=Amount, 
            Payment_Method=Payment_Method, 
            Status="Pending"
        )
        db.session.add(new_payment)
        db.session.commit()
        new_payment.Status = "Paid"
        db.session.commit()
        return new_payment

    @staticmethod
    def get_payment_status(Booking_ID):
        payment = Payment.query.filter_by(Booking_ID=Booking_ID).first()
        return payment.Status if payment else "No payment found"
