from flask import request
from Plane_ticket_app.Services.flight_service import FlightService
from Plane_ticket_app.templates.passenger_views import PassengerView

class FlightController:
    @staticmethod
    def get_flight(Flight_name):
        flight = FlightService.get_flight_by_Flight_name(Flight_name)
        if not flight: # if flight is None:
            return FlightView.render_error('flight not found'), 404
        return FlightView.render_flight(flight), 200

    @staticmethod
    def create_flight():
        data = request.get_json()
        Flight_name = data.get('Flight_name')
        Flight_type = data.get('Flight_type')
        Year_of_Services = data.get('Year_of_Services')
        Departure_Time = data.get('Departure_Time')
        Arrival_Time = data.get('Arrival_Time')

        flight = FlightService.create_flight(Flight_name, Comment)
        return FlightView.render_success('flight created successfully', flight.Flight_name), 201
