from flask import request
from Plane_ticket_app.Services.passenger_services import PassengerService
from Plane_ticket_app.templates.passenger_views import PassengerView

class PassengerController:
    @staticmethod
    def get_passenger(Passenger_ID):
        passenger = PassengerService.get_passenger_by_Passenger_ID(Passenger_ID)
        if not passenger: # if passenger is None:
            return PassengerView.render_error('passenger not found'), 404
        return PassengerView.render_passenger(passenger), 200

    @staticmethod
    def create_passenger():
        data = request.get_json()
        Passenger_ID = data.get('Passenger_ID')
        email = data.get('email')
        password = data.get('password')
        First_name = data.get('First_name', '')
        Last_name = data.get('Last_name', '')
        Passport_number = data.get('Passport_number', '')

        passenger = PassengerService.create_passenger(Passenger_ID, email, password, First_name, Last_name, Passport_number)
        return PassengerView.render_success('passenger created successfully', Passenger.Passenger_ID), 201

    @staticmethod
    def login_passenger():
        data = request.get_json()
        Passenger_ID = data.get('Passenger_ID')
        password = data.get('password')

        passenger = PassengerService.verify_passenger(Passenger_ID, password)
        if passenger:
            return PassengerView.render_success('Login successful', passenger.passenger_id), 200
        return PassengerView.render_error('Invalid Passenger_ID or password'), 401

    