from flask import request, jsonify
from Plane_ticket_app.Services.booking_service import BookingService
from Plane_ticket_app.templates.passenger_views import PassengerView

class BookingController:
    @staticmethod
    def book_ticket():
        Flight_ID = request.form.get('Flight_ID')
        Passenger_ID = request.form.get('Passenger_ID')
        Seat_number = request.form.get('Seat_number')
        Class = request.form.get('Class')
        Price = request.form.get('Price')

        booking = BookingService.book_ticket(Flight_ID, Passenger_ID, Seat_number, Class, Price)
        
        if isinstance(booking, dict):  # Error case
            return PassengerView.render_error(booking["message"]), booking["status"]
            
        return PassengerView.render_success('Booking created successfully', booking.Booking_ID), 201

    @staticmethod
    def get_booking(Booking_ID):
        booking = BookingService.get_booking_by_id(Booking_ID)
        if not booking:
            return PassengerView.render_error('Booking not found'), 404
        return PassengerView.render_booking(booking), 200

    @staticmethod
    def process_payment():
        data = request.get_json()
        Booking_ID = data.get('Booking_ID')
        Amount = data.get('Amount')
        Payment_Method = data.get('Payment_Method')

        if not all([Booking_ID, Amount, Payment_Method]):
            return PassengerView.render_error('Booking ID, Amount and Payment Method are required'), 400

        try:
            BookingService.process_payment(Booking_ID, Amount, Payment_Method)
            return PassengerView.render_success('Payment processed successfully'), 201
        except Exception as e:
            return PassengerView.render_error('Payment processing failed'), 500

    @staticmethod
    def cancel_booking():
        data = request.get_json()
        Booking_ID = data.get('Booking_ID')
        Request_time = data.get('Request_time')
        Reason = data.get('Reason')

        if not all([Booking_ID, Request_time, Reason]):
            return PassengerView.render_error('Missing required fields'), 400

        if BookingService.cancel_booking(Booking_ID, Request_time, Reason):
            return PassengerView.render_success('Booking cancelled successfully'), 200
        return PassengerView.render_error('Booking not found or already cancelled'), 404