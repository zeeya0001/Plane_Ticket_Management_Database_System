from datetime import datetime
from shared.utils.db_utils import db
from shared.models.airline_model import Airline
from shared.models.airport_model import Airport

class Flight(db.Model):
    __tablename__ = 'flight'
    Flight_ID = db.Column(db.Integer, primary_key=True)
    Flight_name = db.Column(db.String(20), nullable=False)
    Departure_Time = db.Column(db.DateTime, nullable=False)
    Arrival_Time = db.Column(db.DateTime, nullable=False)
    Year_of_Services = db.Column(db.Integer, nullable=False)
    Airline_ID = db.Column(db.String(15), db.ForeignKey('airline.Airline_ID'), nullable=False)
    Origin_AP_CODE = db.Column(db.String(10), db.ForeignKey('airport.AP_CODE'), nullable=False)
    Destination_AP_CODE = db.Column(db.String(10), db.ForeignKey('airport.AP_CODE'), nullable=False)
    Flight_type = db.Column(db.String(20), nullable=False)
    Flight_Status = db.Column(db.String(20), nullable=False)
    Flight_Location = db.Column(db.String(20), nullable=False)

    