from datetime import datetime
from shared.utils.db_utils import db
from shared.models.booking_model import Booking

class Payment(db.Model):
    __tablename__ = 'payment'
    Payment_ID = db.Column(db.Integer, primary_key=True)
    Amount = db.Column(db.Numeric(10, 2), nullable=False)
    Payment_Method = db.Column(db.String(20), nullable=False)
    Date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    Booking_ID = db.Column(db.Integer, db.ForeignKey('booking.Booking_ID'), nullable=False)

    