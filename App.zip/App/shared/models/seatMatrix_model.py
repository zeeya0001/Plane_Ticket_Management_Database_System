from shared.utils.db_utils import db
from shared.models.passenger_model import Passenger
from shared.models.flight_model import Flight

class SeatMatrix(db.Model):
    __tablename__ = 'seat_matrix'
    
    seat_id = db.Column(db.Integer, primary_key=True)
    flight_id = db.Column(db.Integer, db.ForeignKey('flight.Flight_ID'), nullable=False)
    passenger_id = db.Column(db.Integer, db.ForeignKey('passenger.Passenger_ID'), nullable=False)
    seat_number = db.Column(db.String(5), nullable=False)
    seat_class = db.Column(db.String(20), nullable=False)
    total_seats_available = db.Column(db.Integer, nullable=False)
    